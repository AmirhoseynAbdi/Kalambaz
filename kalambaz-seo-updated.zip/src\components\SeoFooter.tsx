import React, { useState } from 'react';
import { ChevronDown, ChevronUp, BookOpen, HelpCircle, Sparkles, Award } from 'lucide-react';

interface SeoFooterProps {
  darkMode?: boolean;
}

export const SeoFooter: React.FC<SeoFooterProps> = ({ darkMode = true }) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <footer
      aria-label="درباره بازی کلمباز و راهنمای ووردل فارسی"
      className="w-full max-w-4xl mx-auto mt-4 mb-3 px-2 sm:px-4 text-xs sm:text-sm select-text"
    >
      <div
        className={`rounded-2xl border transition-all duration-300 backdrop-blur-md overflow-hidden ${
          darkMode
            ? 'bg-[#23173b]/85 border-[#523b78]/70 text-[#e9d5ff]'
            : 'bg-[#edf6f1]/90 border-[#82b59d]/75 text-[#18382b]'
        }`}
      >
        {/* Toggle Bar / Preview Header */}
        <button
          type="button"
          onClick={() => setIsOpen(!isOpen)}
          aria-expanded={isOpen}
          className={`w-full flex items-center justify-between px-3.5 py-2.5 sm:px-4 sm:py-3 transition-colors text-right cursor-pointer ${
            darkMode
              ? 'hover:bg-[#2d1f4b]/90 text-[#a7f3d0]'
              : 'hover:bg-[#dfeee5] text-[#1e503c]'
          }`}
        >
          <div className="flex items-center gap-2">
            <span className="text-base sm:text-lg">🥬</span>
            <span className="font-bold text-xs sm:text-sm font-['Lalezar',sans-serif]">
              کلمباز: بازی کلمه، کلمه بازی و ووردل فارسی (راهنما و قوانین بازی)
            </span>
          </div>
          <div className="flex items-center gap-1.5 text-xs font-semibold shrink-0">
            <span>{isOpen ? 'بستن راهنما' : 'مشاهده راهنما'}</span>
            {isOpen ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </div>
        </button>

        {/* Expandable Rich SEO & Instructional Content */}
        {isOpen && (
          <div
            className={`p-4 sm:p-6 border-t space-y-5 leading-relaxed text-right font-medium animate-fade-in ${
              darkMode
                ? 'border-[#4c3773]/60 text-[#f2edfa]'
                : 'border-[#a1cdb7]/60 text-[#17382b]'
            }`}
          >
            {/* Main Title & Intro */}
            <div>
              <h2 className="text-base sm:text-lg font-bold font-['Lalezar',sans-serif] text-[#86efac] mb-2 flex items-center gap-2">
                <BookOpen className="w-4 h-4 inline-block" />
                درباره بازی کلمه و کلمه بازی آنلاین کلمباز (ووردل فارسی)
              </h2>
              <p className="opacity-90 leading-7">
                <strong>کلمباز (Kalambaz)</strong> برترین پلتفرم آنلاین <strong>بازی کلمه</strong> و{' '}
                <strong>کلمه بازی</strong> روزانه به زبان فارسی است که با الهام از بازی پرطرفدار جهانی{' '}
                <strong>ووردل (Wordle)</strong> پیاده‌سازی شده است. در کلمباز، شما هر روز با یک معمای تازه
                روبه‌رو می‌شوید و باید با اتکا به ذهن خلاق و دایره لغات خود، کلمه پنهان روز را در حداکثر ۶ حدس
                کشف کنید.
              </p>
            </div>

            {/* How to Play & Colors */}
            <div className="space-y-2">
              <h3 className="font-bold text-sm sm:text-base text-[#d8b4fe] flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-emerald-400" />
                قوانین و راهنمای ووردل فارسی؛ رنگ‌ها چه می‌گویند؟
              </h3>
              <p className="opacity-90">
                در هر مرحله از این <strong>بازی حدس کلمات</strong>، پس از ثبت هر حدس، رنگ خانه‌ها وضعیت حروف را
                مشخص می‌کنند:
              </p>
              <ul className="list-disc list-inside space-y-1.5 pr-1 opacity-90">
                <li>
                  <span className="font-bold text-emerald-400">سبز فسفری:</span> حرف درست است و دقیقاً در جایگاه صحیح کلمه قرار دارد.
                </li>
                <li>
                  <span className="font-bold text-yellow-300">زرد کلمی:</span> این حرف در کلمه مخفی امروز وجود دارد، اما جایگاه آن در این خانه نیست.
                </li>
                <li>
                  <span className="font-bold text-gray-400">خاکستری:</span> این حرف به هیچ وجه در کلمه روز استفاده نشده و باید از حدس‌های بعدی حذف شود.
                </li>
              </ul>
            </div>

            {/* Why Kalambaz is Unique */}
            <div className="space-y-2">
              <h3 className="font-bold text-sm sm:text-base text-[#86efac] flex items-center gap-1.5">
                <Award className="w-4 h-4 text-purple-400" />
                ویژگی‌های برتر بازی کلمات کلمباز
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 pt-1">
                <div
                  className={`p-3 rounded-xl border ${
                    darkMode
                      ? 'bg-[#1e1333]/90 border-[#4d376f]'
                      : 'bg-[#e2f1e8] border-[#a0cbb5]'
                  }`}
                >
                  <h4 className="font-bold text-xs text-[#86efac] mb-1">۳ سطح بازی (۴، ۵ و ۶ حرفی)</h4>
                  <p className="text-[11px] opacity-85 leading-5">
                    برخلاف سایر نسخه‌های وردل، کلمباز از کلمات ۴، ۵ و ۶ حرفی پشتیبانی می‌کند.
                  </p>
                </div>
                <div
                  className={`p-3 rounded-xl border ${
                    darkMode
                      ? 'bg-[#1e1333]/90 border-[#4d376f]'
                      : 'bg-[#e2f1e8] border-[#a0cbb5]'
                  }`}
                >
                  <h4 className="font-bold text-xs text-[#86efac] mb-1">استریک و جدول امتیازات</h4>
                  <p className="text-[11px] opacity-85 leading-5">
                    با بازی منظم هر روزه زنجیره بردهای خود (Streak) را حفظ کرده و پیشرفت کنید.
                  </p>
                </div>
                <div
                  className={`p-3 rounded-xl border ${
                    darkMode
                      ? 'bg-[#1e1333]/90 border-[#4d376f]'
                      : 'bg-[#e2f1e8] border-[#a0cbb5]'
                  }`}
                >
                  <h4 className="font-bold text-xs text-[#86efac] mb-1">کیبورد اختصاصی فارسی</h4>
                  <p className="text-[11px] opacity-85 leading-5">
                    طراحی هوشمند برای تایپ سریع در موبایل و دسکتاپ به همراه نمایش وضعیت حروف.
                  </p>
                </div>
              </div>
            </div>

            {/* FAQ Summary */}
            <div className="space-y-2 border-t pt-3">
              <h3 className="font-bold text-sm text-[#d8b4fe] flex items-center gap-1.5">
                <HelpCircle className="w-4 h-4 text-emerald-400" />
                پرسش‌های متداول کلمه بازی ووردل فارسی
              </h3>
              <div className="space-y-2 text-xs opacity-90">
                <p>
                  <strong>آیا کلمه بازی کلمباز رایگان است؟</strong> بله، تمامی مراحل و قابلیت‌های کلمباز کاملاً
                  رایگان و بدون نیاز به خرید یا نصب در دسترس است.
                </p>
                <p>
                  <strong>کلمات جدید چه ساعتی به‌روز می‌شوند؟</strong> هر شب ساعت ۲۴ (۱۲ شب) معما و کلمه جدید
                  روز برای تمام کاربران سراسر جهان بارگذاری می‌شود.
                </p>
              </div>
            </div>

            {/* Copyright & Keywords Footer */}
            <div className="pt-2 border-t text-[11px] opacity-75 flex flex-wrap items-center justify-between gap-2">
              <span>© {new Date().getFullYear()} کلمباز (Kalambaz.ir) — تمام حقوق محفوظ است.</span>
              <span>کلمه بازی • بازی کلمه • ووردل فارسی • وردل • جدول کلمات روزانه</span>
            </div>
          </div>
        )}
      </div>
    </footer>
  );
};
